from dataImporter import *
from experiment import *
from utilityFunctions import *
from tsFeatures import *
from afterAnalysis import *
from visualization import *

import time

selection_attributes = ['enterpriseToEbitda', 'sector', 'industry', 'marketCap', 'country']

#df_original, cat, num, features = getData("Stock5YSmall",countries=['Netherlands'],attributes=selection_attributes)
df_original, cat, num, features = getData("Stock5YSmall", countries=['Germany', 'Netherlands', 'Belgium'],attributes=selection_attributes)
# df_original, cat, num, features = getData("Stock5YLarge")
df = df_original.copy()

df_test = df
df_test = df_test.reset_index(drop=True)

exp = Experiment("Observation cluster based - ED", df_test, features, w_var=50, d_var=3, q_var=50,
                 min_coverage=0.001, normalization_var=percent_change_norm,
                 min_coverage_abs=3)  # normalization_var=percentual_differences,
exp.prepare(
    distance_measure_matrix=euclidean_distance_slopes)  # euclidean_distance_time_points, euclidean_distance_slopes, euclidean_distance_concav, polygonal_distance
euclidean_slope_distance_matrix = exp.distance_matrix

pickle_title = './euclidean_slope_distance_matrix_NLGEBE.pkl'
np.save(pickle_title, euclidean_slope_distance_matrix)

import numpy as np
import heapq


class botumUpSearch:

    def __init__(self, df, distance_matrix, number_of_row_pairs, depth, q, min_coverage_perc=0.01, min_coverage_abs=3):

        self.matrix = distance_matrix
        self.x = number_of_row_pairs
        self.d = depth
        self.df = df
        self.q = q
        self.min_coverage_perc = min_coverage_perc
        self.min_coverage_abs = min_coverage_abs

    # TODO increase combination of two to combination of x
    def find_min_indices(matrix, x):

        min_heap = []
        heapq.heapify(min_heap)
        n = len(matrix)

        for i in range(n):
            for j in range(i + 1, n):
                if len(min_heap) < x:
                    heapq.heappush(min_heap, (-matrix[i][j], (i, j)))
                else:
                    if matrix[i][j] < -min_heap[0][0]:
                        heapq.heappop(min_heap)
                        heapq.heappush(min_heap, (-matrix[i][j], (i, j)))

        return [idx for val, idx in min_heap]

    # TODO apply binning for numerical attributes
    def get_common_attributes(row1, row2, d):

        common_attributes = []
        for combination in combinations(row1.iteritems(), d):
            attributes = [f"{attribute} == '{value}'" for attribute, value in combination]
            if all(row2.get(attribute) == value for attribute, value in combination):
                common_attributes.append(attributes)
        return common_attributes

    def get_unique_lists(list_of_lists):
        unique_lists = [list(x) for x in set(tuple(set(sublist)) for sublist in list_of_lists)]
        return unique_lists

    def findQuality(self, quality_measure=cluster_based_quality_measure, comparison_type="complement",
                    size_corr=no_size_corr, **kwargs):

        self.running_time = time.time()
        self.correct_for_size_var = size_corr
        self.quality_measure = quality_measure
        self.quality_measure_kwargs_placeholder = kwargs

        min_heap = []
        len_df = len(self.df)

        promising_combinations = botumUpSearch.find_min_indices(self.matrix, self.x)
        # TODO in line below it only works when target attribute is the last attribute
        candidate_descriptions = [botumUpSearch.get_common_attributes(self.df.iloc[promising_combinations[i][0]][:-1],
                                                                      self.df.iloc[promising_combinations[i][1]][:-1],
                                                                      d) for i in range(len(promising_combinations)) for
                                  d in range(1, self.d + 1)]
        unique_candidate_descriptions = botumUpSearch.get_unique_lists(
            [item for sublist in candidate_descriptions for item in sublist])

        for desc in unique_candidate_descriptions:
            ind = self.df.query(as_string(desc))
            if satisfies_all(desc, ind, len_df, self.min_coverage_perc, self.min_coverage_abs):

                # TODO adapt so that quality measure is adaptable
                quality, coverage = eval_quality(ind, self.df, 'target', quality_measure, comparison_type,
                                                 distance_matrix=self.matrix, correct_for_size=size_corr)

                if len(min_heap) < self.q:
                    heapq.heappush(min_heap, (desc, quality, coverage))
                else:
                    if quality < -min_heap[0][1]:
                        heapq.heappop(min_heap)
                        heapq.heappush(min_heap, (desc, quality, coverage))

        self.running_time = time.time() - self.running_time

        self.result = sorted(min_heap, key=lambda x: x[1], reverse=True)
        quals = [i[1] for i in min_heap]
        covs = [i[2] for i in min_heap]
        self.avg_quality = sum(quals) / len(quals)
        self.avg_coverage = sum(covs) / len(covs)
        self.descs = [i[0] for i in min_heap]

    def print_outcome(self):

        print('Outcome of bottumUpSearch is:')
        print(' ')
        print('avg_quality = ', round(self.avg_quality, 3))
        print('avg_coverage = ', round(self.avg_coverage, 3))
        print(' ')

        for z in self.result:
            conjunction = " Ʌ ".join(["(" + condition.replace(" == ", "=").strip() + ")" for condition in z[0]])
            print('description =', conjunction)
            print('quality =', round(z[1], 3))
            print('coverage =', round(z[2], 3))
            print(' ')

    def save(self, title, **kwargs):

        self.title = title

        #         try:
        #             pickle_results = pickle.load(open("results.pkl", "rb"))
        #         except:
        #             pickle_results = pd.DataFrame()

        #         quality_measure_kwargs_placeholder = self.quality_measure_kwargs

        #         if 'distance_matrix' in quality_measure_kwargs_placeholder:
        #             del quality_measure_kwargs_placeholder['distance_matrix']

        pickle_results = pd.DataFrame(columns=['title', 'running_time', 'descs', 'avg_quality', 'avg_coverage',
                                               'quality_measure', 'x', 'd', 'q',
                                               'correct_for_size_var', 'result'])
        pickle_results.loc[len(pickle_results)] = [self.title, self.running_time, self.descs, self.avg_quality,
                                                   self.avg_coverage,
                                                   self.quality_measure, self.x, self.d, self.q,
                                                   self.correct_for_size_var,
                                                   self.result]  # quality_measure_kwargs_placeholder, self.kwargs

        return pickle_results


#         pickle_results.to_pickle('results.pkl')
#         pickle_results.to_excel('/Users/bengelen003/OneDrive - pwc/Code/ESTM/results.xlsx', index=False)


bus = botumUpSearch(exp.df.reset_index(drop=True), exp.distance_matrix, 100, 3, 10)
bus.findQuality(quality_measure=cluster_based_quality_measure, comparison_type="complement", size_corr=sqrt_size)

test = bus.save('joe')
print(test)